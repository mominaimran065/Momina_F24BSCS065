#ifndef BST_H
#define BST_H

#include <iostream>
#include <string>
#include <vector>   

using namespace std;

enum RelationType { LESS, GREATER, EQUAL };

// FLIGHT CLASS
class Flight
{
private:
    string flightID;
    string destination;
    string status;
    int departureTime;
    int flightDuration;

public:
    Flight()
    {
        flightID = "";
        destination = "";
        departureTime = 0;
        flightDuration = 0;
        status = "";
    }

    void SetFlight(string id, string dest, int deptime, int duration, string st)
    {
        flightID = id;
        destination = dest;
        departureTime = deptime;
        flightDuration = duration;
        status = st;
    }

    void GetFlight() const
    {
        cout << endl;
        cout << "FlightID: " << flightID << endl;
        cout << "Destination: " << destination << endl;
        cout << "Departure Time: " << departureTime << endl;
        cout << "Duration: " << flightDuration << endl;
        cout << "Status: " << status << endl;
        cout << endl;
    }

    RelationType ComparedTo(Flight otherflight) const
    {
        if (flightID < otherflight.flightID)
            return LESS;
        else if (flightID > otherflight.flightID)
            return GREATER;
        else
            return EQUAL;
    }

    // Getters
    string GetFlightID() const 
    { 
        return flightID; 
    }
    string GetDestination() const 
    {
        return destination; 
    }
    string GetStatus() const 
    { 
        return status; 
    }
    int GetDepartureTime() const 
    { 
        return departureTime; 
    }
    int GetFlightDuration() const 
    { 
        return flightDuration; 
    }
};


// NODE CLASS
class Node
{
public:
    Node* parent;
    Node* left;
    Node* right;
    int height;     
    Flight key;
    int rotationCount;

    Node(Flight f)
    {
        parent = NULL;
        left = NULL;
        right = NULL;
        height = 1;    // Initial height
        key = f;
        rotationCount = 0;
    }

    Node(int k)
    {
        parent = NULL;
        left = NULL;
        right = NULL;
        height = 1;
        rotationCount = 0;
        // Fake flight object for numeric AVL usage
        key.SetFlight(to_string(k), "", 0, 0, "");
    }
};

// BST CLASS
class BST
{
private:
    Node* root;

    Node* Minimum(Node* x)
    {
        while (x->left != NULL)
            x = x->left;
        return x;
    }

    void Transplant(Node* u, Node* v)
    {
        if (u->parent == NULL)
            root = v;
        else if (u == u->parent->left)
            u->parent->left = v;
        else
            u->parent->right = v;

        if (v != NULL)
            v->parent = u->parent;
    }

    void InOrder(Node* x)
    {
        if (x != NULL)
        {
            InOrder(x->left);
            x->key.GetFlight();
            InOrder(x->right);
        }
    }

    // recursive helper for printStructure
    void printStructureRec(Node* node, string parent) 
    {
        if (!node) return;
        string left = (node->left ? node->left->key.GetFlightID() : string("NULL"));
        string right = (node->right ? node->right->key.GetFlightID() : string("NULL"));

        cout << "Node: " << node->key.GetFlightID()
             << " | Left: " << left
             << " | Right: " << right
             << " | Parent: " << parent
             << " | Height: " << node->height
            << endl;

        printStructureRec(node->left, node->key.GetFlightID());
        printStructureRec(node->right, node->key.GetFlightID());
    }

    // inorder collector helper
    void collectInorderRec(Node* node, vector<Flight>& out) 
    {
        if (!node) return;
        collectInorderRec(node->left, out);
        out.push_back(node->key);
        collectInorderRec(node->right, out);
    }

    // skewness recursive check
    bool isSkewedRec(Node* node) 
    {
        if (!node) return true;
        // if node has two children it's not skewed
        if (node->left && node->right) return false;
        // continue down the only child
        return isSkewedRec(node->left ? node->left : node->right);
    }


public:

    BST()
    {
        root = NULL;
    }

    Node* GetRoot()
    {
        return root;
    }

  
    // INSERT
    void Insert(Node* x)
    {
        Node* y = NULL;
        Node* z = root;

        while (z != NULL)
        {
            y = z;
            if (x->key.ComparedTo(z->key) == LESS)
                z = z->left;
            else
                z = z->right;
        }

        x->parent = y;

        if (y == NULL)
            root = x;
        else if (x->key.ComparedTo(y->key) == LESS)
            y->left = x;
        else
            y->right = x;
    }

 
    // DELETE
    void Delete(Node* x)
    {
        Node* y = NULL;

        if (x->left == NULL)
            Transplant(x, x->right);

        else if (x->right == NULL)
            Transplant(x, x->left);

        else
        {
            y = Minimum(x->right);

            if (y->parent != x)
            {
                Transplant(y, y->right);
                y->right = x->right;
                if (y->right != NULL) y->right->parent = y;
            }

            Transplant(x, y);
            y->left = x->left;
            if (y->left != NULL) y->left->parent = y;
        }
    }

    // SEARCH
    Node* Search(Node* x, Flight k)
    {
        if (x == NULL || k.ComparedTo(x->key) == EQUAL)
            return x;

        if (k.ComparedTo(x->key) == LESS)
            return Search(x->left, k);
        else
            return Search(x->right, k);
    }

    // DISPLAY
    void Display()
    {
        InOrder(root);
    }

    // print node relations (Parent | Left | Right)
    void printStructure() {
        cout << "\nBST Structure (Parent | Left | Right | Height ):\n";
        if (root == NULL) {
            cout << "BST is empty.\n";
            return;
        }
        printStructureRec(root, string("ROOT"));
    }

    // collect inorder flights into vector (used by suggestOptimalRoots)
    void collectInorder(vector<Flight>& out) 
    {
        collectInorderRec(root, out);
    }

    // check if BST is skewed (degenerate chain)
    bool isSkewed() 
    {
        if (root == NULL) 
            return false;
        return isSkewedRec(root);
    }

    void checkSkewHelper(Node* node, bool& leftSkew, bool& rightSkew) 
    {
        if (!node) return;
        // if a node has a right child -> cannot be left-skewed
        if (node->right != nullptr) leftSkew = false;
        // if a node has a left child -> cannot be right-skewed
        if (node->left != nullptr) rightSkew = false;

        checkSkewHelper(node->left, leftSkew, rightSkew);
        checkSkewHelper(node->right, leftSkew, rightSkew);
    }

    // public API: returns a human-readable result
    string checkSkew() 
    {
        if (root == nullptr) 
            return string("BST is empty.");

        bool leftSkew = true;
        bool rightSkew = true;

        checkSkewHelper(root, leftSkew, rightSkew);

        if (leftSkew && !rightSkew)
            return string("BST is Left-Skewed.");

        if (rightSkew && !leftSkew) 
            return string("BST is Right-Skewed.");

        if (leftSkew && rightSkew) 
        {
            return string("BST is Not Skewed.");
        }
        return string("BST is Not Skewed.");
    }

    // suggest "optimal" possible roots (middle of inorder)
    void suggestOptimalRoots() 
    {
        vector<Flight> sorted;
        collectInorder(sorted);
        if (sorted.empty()) 
        {
            cout << "BST is empty." << endl;
            return;
        }
        int n = (int)sorted.size();
        int mid = n / 2;
        cout << endl;
        cout << "--- Suggested Optimal Roots for Balanced BST ---" << endl;
        cout << "Best Root: " << sorted[mid].GetFlightID() << endl;
        if (n > 2) 
        {
            cout << "Other possible roots: ";
            if (mid - 1 >= 0) 
                cout << sorted[mid - 1].GetFlightID() << " ";

            if (mid + 1 < n)
                cout << sorted[mid + 1].GetFlightID() << " ";
            cout << endl;
        }
    }
};

#endif
//end of Bst.h


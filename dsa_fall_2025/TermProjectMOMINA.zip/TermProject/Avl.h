#ifndef AVL_H
#define AVL_H

#include <iostream>
#include "bst.h"     // Uses Node and Flight from bst.h
using namespace std;

class AVL 
{
private:
    Node* root;
    int rotations;

    int Height(Node* n) 
    {
        return (n == NULL) ? 0 : n->height;
    }

    void UpdateHeight(Node* n)
    {
        if (n) n->height = 1 + max(Height(n->left), Height(n->right));
    }

    int BalanceFactor(Node* n) 
    {
        return (n == NULL) ? 0 : Height(n->left) - Height(n->right);
    }

    // Right rotation 
    Node* RightRotate(Node* y) 
    {
        Node* x = y->left;
        Node* T2 = x->right;

        // rotation
        x->right = y;
        y->left = T2;

        // update parents
        x->parent = y->parent;
        y->parent = x;
        if (T2) T2->parent = y;

        // update heights
        UpdateHeight(y);
        UpdateHeight(x);

        x->rotationCount++;
        rotations++;
        return x;
    }

    // Left rotation
    Node* LeftRotate(Node* x) 
    {
        Node* y = x->right;
        Node* T2 = y->left;

        // rotation
        y->left = x;
        x->right = T2;

        // update parents
        y->parent = x->parent;
        x->parent = y;
        if (T2) T2->parent = x;

        // update heights
        UpdateHeight(x);
        UpdateHeight(y);

        y->rotationCount++;
        rotations++;
        return y;
    }

    // Balance subtree rooted at node
    Node* Balance(Node* node) 
    {
        if (!node) return node;

        UpdateHeight(node);
        int bf = BalanceFactor(node);

        // LL
        if (bf > 1 && BalanceFactor(node->left) >= 0)
            return RightRotate(node);

        // LR
        if (bf > 1 && BalanceFactor(node->left) < 0) 
        {
            node->left = LeftRotate(node->left);
            if (node->left) node->left->parent = node;

            Node* newRoot = RightRotate(node);
            newRoot->rotationCount++;   // count LR second rotation
            return newRoot;

        }

        // RR
        if (bf < -1 && BalanceFactor(node->right) <= 0)
            return LeftRotate(node);

        // RL
        if (bf < -1 && BalanceFactor(node->right) > 0) 
        {
            node->right = RightRotate(node->right);
            if (node->right) node->right->parent = node;

            Node* newRoot = LeftRotate(node);
            newRoot->rotationCount++;  // count RL second rotation
            return newRoot;

        }

        return node;
    }

    // Insert node into AVL by Flight key
    Node* insertRec(Node* node, Node* newNode) 
    {
        if (!node) 
        {
            // ensure children/parent of newNode are fresh
            newNode->left = newNode->right = NULL;
            newNode->height = 1;
            return newNode;
        }

        RelationType cmp = newNode->key.ComparedTo(node->key);
        if (cmp == LESS) 
        {
            node->left = insertRec(node->left, newNode);
            if (node->left) node->left->parent = node;
        }
        else if (cmp == GREATER) 
        {
            node->right = insertRec(node->right, newNode);
            if (node->right) node->right->parent = node;
        }
        else 
        {
            // duplicate FlightID � ignore insertion 
            return node;
        }

        return Balance(node);
    }

    Node* minValue(Node* node) 
    {
        Node* cur = node;
        while (cur && cur->left) cur = cur->left;
        return cur;
    }

    Node* deleteRec(Node* node, Flight f) 
    {
        if (!node) return node;

        RelationType cmp = f.ComparedTo(node->key);
        if (cmp == LESS)
            node->left = deleteRec(node->left, f);
        else if (cmp == GREATER)
            node->right = deleteRec(node->right, f);
        else {
            // found node
            if (!node->left || !node->right) 
            {
                Node* temp = node->left ? node->left : node->right;

                if (!temp) 
                {
                    // no child
                    temp = node;
                    node = NULL;
                    delete temp;
                }
                else 
                {
                    Node* copy = new Node(temp->key);
                    copy->left = temp->left;
                    copy->right = temp->right;
                    copy->parent = node->parent;
                    copy->height = temp->height;
                    *node = *copy; // copy values into node
                    delete copy;
                }
            }
            else 
            {
                // two children
                Node* temp = minValue(node->right);
                node->key = temp->key;
                node->right = deleteRec(node->right, temp->key);
            }
        }

        if (!node) return node;
        return Balance(node);
    }

    Node* searchRec(Node* node, Flight f) 
    {
        if (!node) return NULL;
        RelationType cmp = f.ComparedTo(node->key);
        if (cmp == EQUAL) return node;
        if (cmp == LESS) return searchRec(node->left, f);
        else return searchRec(node->right, f);
    }

    // inorder traversal helper
    void inorderRec(Node* node) 
    {
        if (!node) return;
        inorderRec(node->left);
        // we will not print here (main prints in required format), but for completeness:
        // node->key.GetFlight();
        inorderRec(node->right);
    }

    void printStructureRec(Node* node, string parent) 
    {
        if (!node) return;
        string left = (node->left ? node->left->key.GetFlightID() : string("NULL"));
        string right = (node->right ? node->right->key.GetFlightID() : string("NULL"));

        cout << "Node: " << node->key.GetFlightID()
            << " | Left: " << left
            << " | Right: " << right
            << " | Parent: " << parent
            << " | Height: " << node->height
            << " | Rot: " << node->rotationCount
            << endl;

        printStructureRec(node->left, node->key.GetFlightID());
        printStructureRec(node->right, node->key.GetFlightID());
    }


public:
    AVL() 
    { 
        root = NULL; 
        rotations = 0; 
    }

    // Insert a node pointer 
    void Insert(Node* n) 
    {
        root = insertRec(root, n);
        if (root) 
            root->parent = NULL;
    }

    // Delete by Flight
    void DeleteByFlight(Flight f) 
    {
        root = deleteRec(root, f);
        if (root) 
            root->parent = NULL;
    }

    // Search by Flight
    Node* SearchFlight(Flight f) 
    {
        return searchRec(root, f);
    }

    // expose root for traversal in main
    Node* GetRoot() 
    { 
        return root; 
    }

    // print inorder using main's printing or here (kept minimal)
    void Inorder() 
    { 
        inorderRec(root); 
    }

    int GetRotationCount() const 
    { 
        return rotations; 
    }

    void printStructure() 
    {
        cout << endl;
        cout << "AVL Structure (Parent | Left | Right | Height | Rotations):" << endl;
        if (root == NULL) 
        {
            cout << "AVL is empty.\n";
            return;
        }
        printStructureRec(root, string("ROOT"));
    }
};

#endif
//end of Avl.h

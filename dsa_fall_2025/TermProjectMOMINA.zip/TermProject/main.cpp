// main.cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <ctime>
#include <functional>

#include "Bst.h"
#include "Avl.h"
#include "Bfs.h"

using namespace std;

// --- Formatting helpers
string formatDeparture(int hour) 
{
    int h = ((hour % 24) + 24) % 24;
    ostringstream oss;
    if (h < 10) oss << '0';
    oss << h << ":00";
    return oss.str();
}
string formatDuration(int dur) 
{
    ostringstream oss;
    oss << dur << "h";
    return oss.str();
}

void printFlightRow(const Flight& f)
{
    cout << left
        << setw(10) << f.GetFlightID()
        << setw(12) << formatDeparture(f.GetDepartureTime())
        << setw(10) << formatDuration(f.GetFlightDuration())
        << setw(12) << f.GetStatus()
        << endl;
}


// Inorder print for BST (useing Node* from bst.h)
void printBSTInorder(Node* root) 
{
    if (!root) return;
    printBSTInorder(root->left);
    printFlightRow(root->key);
    printBSTInorder(root->right);
}

// collect flights inorder for saving
void collectFlightsInorder(Node* root, vector<Flight>& out) 
{
    if (!root) return;
    collectFlightsInorder(root->left, out);
    out.push_back(root->key);
    collectFlightsInorder(root->right, out);
}

// Load flights: insert into BST and AVL (separate Node objects)
bool loadFlights(const string& filename, BST& bst, AVL& avl) 
{
    ifstream fin(filename);
    if (!fin.is_open()) return false;

    string line;
    while (getline(fin, line)) 
    {
        if (line.empty()) 
            continue;
        istringstream iss(line);
        string id, dest, status;
        int dep, dur;

        if (!(iss >> id >> dest >> dep >> dur >> status)) 
             continue;

        Flight f;
        f.SetFlight(id, dest, dep, dur, status);

        Node* nb = new Node(f);
        bst.Insert(nb);

        Node* na = new Node(f);
        avl.Insert(na);
    }
    fin.close();
    return true;
}

// Save BST inorder to flights.txt
bool saveFlights(const string& filename, BST& bst) 
{
    vector<Flight> flights;
    collectFlightsInorder(bst.GetRoot(), flights);
    ofstream fout(filename);
    if (!fout.is_open()) 
        return false;
    for (auto& f : flights) 
    {
        fout << f.GetFlightID() << " "
            << f.GetDestination() << " "
            << f.GetDepartureTime() << " "
            << f.GetFlightDuration() << " "
            << f.GetStatus() << endl;
    }
    fout.close();
    return true;
}

// Read airports first (to know count), then construct Graph and load routes
bool readAirportsFile(const string& airportsFile, vector<string>& airportNames) 
{
    ifstream fin(airportsFile);
    if (!fin.is_open()) 
        return false;

    int id; string name;
    int maxId = -1;
    vector<pair<int, string>> entries;
    while (fin >> id >> name) 
    {
        entries.emplace_back(id, name);
        if (id > maxId) 
            maxId = id;
    }
    fin.close();
    if (maxId < 0) 
        return false;

    airportNames.assign(maxId + 1, "");
    for (auto& p : entries) 
        airportNames[p.first] = p.second;
    return true;
}

// Load routes into an existing Graph
bool loadRoutesToGraph(const string& routesFile, Graph& g) 
{
    ifstream fin(routesFile);
    if (!fin.is_open())
        return false;

    int u, v;

    while (fin >> u >> v) 
        g.addEdge(u, v);

    fin.close();
    return true;
}

int main() 
{
    const string flightsFile = "flights.txt";
    const string airportsFile = "airports.txt";
    const string routesFile = "routes.txt";

    BST bst;
    AVL avl;

    // read airports list to determine graph size and names
    vector<string> airportNames;
    if (!readAirportsFile(airportsFile, airportNames)) 
    {
        cout << "Warning: can't open " << airportsFile << ". BFS will have default empty names.\n";
        // make a default small list to avoid crashes
        airportNames = { "Karachi","Lahore","Islamabad","Skardu","Gwadar","Quetta" };
    }

    int airportCount = (int)airportNames.size();
    Graph g(airportCount);
    for (int i = 0; i < airportCount; ++i) 
        g.setAirportName(i, airportNames[i]);

    // Load routes
    if (!loadRoutesToGraph(routesFile, g)) 
    {
        cout << "Warning: can't open " << routesFile << ". No routes loaded.\n";
    }

    //  Load flights into BST and AVL
    if (!loadFlights(flightsFile, bst, avl)) 
    {
        cout << "Warning: can't open " << flightsFile << ". No flights loaded.\n";
    }

    // Menu 
    int choice = 0;
    do {
        cout << endl;
        cout << "------------------------------" << endl;
        cout << endl;
        cout << "Flight Management System" << endl;
        cout << endl;
        cout << "------------------------------" << endl;;
        cout << "1. Add New Flight" << endl;
        cout << "2. Search Flight" << endl;
        cout << "3. Delete Flight" << endl;
        cout << "4. Display All Flights" << endl;
        cout << "5. Display Flights + Rotation Info" << endl;
        cout << "6. Compare Search Time (BST vs AVL)" << endl;
        cout << "7. Plan Trip from Airport A to B " << endl;
        cout << "8. Visualize BST Structure" << endl;
        cout << "9. Visualize AVL Structure" << endl;
        cout << "10. Check BST Skewness" << endl;
        cout << "11. Suggest Optimal Roots (Balance BST)" << endl;
        cout << "12. Exit" << endl;;
        cout << "Enter your choice: ";
        if (!(cin >> choice)) 
        {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Invalid input. Try again.\n";
            continue;
        }

        //insert a flight
        if (choice == 1) 
        {
            string id, dest, status; int dep, dur;

            cout << "Enter Flight ID: "; cin >> id;
            cout << "Enter Destination: "; cin >> dest;
            cout << "Enter Departure Time (hour 0-23): "; cin >> dep;
            cout << "Enter Duration (hours): "; cin >> dur;
            cout << "Enter Status (On-time/Delayed/Cancelled): "; cin >> status;

            Flight f; f.SetFlight(id, dest, dep, dur, status);
            Node* nb = new Node(f);
            bst.Insert(nb);
            Node* na = new Node(f);
            avl.Insert(na);

            cout << endl;
            cout << "Flight added successfully.\n";
            cout << endl;
        }

        //search a flight
        else if (choice == 2) 
        {
            string id; 
            cout << "Enter Flight ID to search: "; 
            cin >> id;

            Flight temp; 
            temp.SetFlight(id, "", 0, 0, "");

            Node* res = bst.Search(bst.GetRoot(), temp);
            if (res) 
            {
                cout << "\nSearch Result (BST):\n";

                cout << left
                    << setw(12) << "FlightID"
                    << setw(12) << "Departure"
                    << setw(10) << "Duration"
                    << setw(12) << "Status" << endl;

                cout << left
                    << setw(12) << res->key.GetFlightID()
                    << setw(12) << formatDeparture(res->key.GetDepartureTime())
                    << setw(10) << formatDuration(res->key.GetFlightDuration())
                    << setw(12) << res->key.GetStatus()
                    << endl;

            }
            else cout << "Flight not found.\n";
        }

        //delete a flight
        else if (choice == 3) 
        {
            string id; 
            cout << "Enter Flight ID to delete: "; 
            cin >> id;

            Flight temp;
            temp.SetFlight(id, "", 0, 0, "");

            Node* toDel = bst.Search(bst.GetRoot(), temp);
            if (toDel) 
            {
                bst.Delete(toDel);
                avl.DeleteByFlight(temp);
                cout << "Flight deleted.\n";
            }
            else cout << "Flight not found.\n";
        }

        //display all flights
        else if (choice == 4) 
        {
            cout << "\nBST Inorder Display:\n";
            cout << left
                << setw(10) << "FlightID"
                << setw(12) << "Departure"
                << setw(10) << "Duration"
                << setw(12) << "Status"
                << endl;
            printBSTInorder(bst.GetRoot());
        }

        // AVL inorder + total rotations
        else if (choice == 5)
        {
            cout << "\nAVL Inorder Display:\n";
            cout << left
                << setw(10) << "FlightID"
                << setw(12) << "Departure"
                << setw(10) << "Duration"
                << setw(12) << "Status"
                << setw(10) << "Rotations"
                << "\n";


            // inorder print AVL
            function<void(Node*)> avlPrint = [&](Node* n) 
                {
                if (!n) return;
                avlPrint(n->left);
                cout << left
                    << setw(10) << n->key.GetFlightID()
                    << setw(12) << formatDeparture(n->key.GetDepartureTime())
                    << setw(10) << formatDuration(n->key.GetFlightDuration())
                    << setw(12) << n->key.GetStatus()
                    << setw(10) << n->rotationCount       
                    << "\n";

                avlPrint(n->right);
                };

            avlPrint(avl.GetRoot());

            cout << "\nTotal rotations (AVL): " << avl.GetRotationCount() << "\n";
        }

        // Compare search time (averaged)
        else if (choice == 6)
        {
            string id;
            cout << "Enter Flight ID to compare search time: ";
            cin >> id;

            Flight temp;
            temp.SetFlight(id, "", 0, 0, "");

            // FIRST check existence in both BST & AVL before timing
            Node* bstCheck = bst.Search(bst.GetRoot(), temp);
            Node* avlCheck = avl.SearchFlight(temp);

            if (bstCheck == NULL || avlCheck == NULL)
            {
                cout << "\nFlight ID '" << id << "' does NOT exist in the system!\n";
                cout << "Search time comparison aborted.\n";
                continue;
            }

            const int ITERS = 100000; 

            for (int i = 0; i < 100; ++i) 
            {
                (void)bst.Search(bst.GetRoot(), temp);
                (void)avl.SearchFlight(temp);
            }

            // Measure BST total time
            clock_t bstStart = clock();
            for (int i = 0; i < ITERS; ++i) 
            {
                (void)bst.Search(bst.GetRoot(), temp);
            }
            clock_t bstEnd = clock();

            // Measure AVL total time
            clock_t avlStart = clock();
            for (int i = 0; i < ITERS; ++i) 
            {
                (void)avl.SearchFlight(temp);
            }
            clock_t avlEnd = clock();

            double totalBstSec = double(bstEnd - bstStart) / CLOCKS_PER_SEC;
            double totalAvlSec = double(avlEnd - avlStart) / CLOCKS_PER_SEC;
            double avgBstSec = totalBstSec / ITERS;
            double avgAvlSec = totalAvlSec / ITERS;

            cout << fixed << setprecision(9);
            cout << "\nSearch Time Comparison (averaged over " << ITERS << " runs):\n";
            cout << "BST total: " << totalBstSec << " sec, avg: " << avgBstSec << " sec\n";
            cout << "AVL total: " << totalAvlSec << " sec, avg: " << avgAvlSec << " sec\n";
            continue;
        }

        //plan route from airport A to B
        else if (choice == 7) 
        {
            cout << "\nAirports List:\n";
            for (int i = 0; i < (int)airportNames.size(); ++i)
                cout << i << " - " << airportNames[i] << "\n";

            int src, dest; 
            cout << "Enter source ID: "; 
            cin >> src; 
            cout << "Enter destination ID: ";
            cin >> dest;
            if (src < 0 || src >= (int)airportNames.size() || dest < 0 || dest >= (int)airportNames.size()) 
            {
                cout << "Invalid airport IDs.\n";
            }
            else 
            {
                g.BFS(src);              // prints table
                cout << "\nMinimum stops from " << airportNames[src] << " to " << airportNames[dest] << ": ";
                g.printMinStops(dest);
                g.printRoute(src, dest);
            }
        }
        //BST TREE Visualization
        else if (choice == 8) 
        {
            cout << "\nVisualize BST Structure\n";
            bst.printStructure();
        }

        // AVL Visualization
        else if (choice == 9) 
        {
                cout << "\nVisualize AVL Structure\n";
                avl.printStructure();
        }

        // Check BST Skewness
        else if (choice == 10) 
        {
            cout << "\nChecking BST Skewness: \n";
            cout << bst.checkSkew() << "\n";

            vector<Flight> tmp;
            bst.collectInorder(tmp);
            cout << "BST node count: " << tmp.size() << "\n";
        }    

        //Suggest optimal roots
        else if (choice == 11) 
        {
             cout << "\nSuggest Optimal Roots\n";
             bst.suggestOptimalRoots();
        }

        //exit
        else if (choice == 12) 
        {
             if (saveFlights(flightsFile, bst))
                cout << "Flights saved to " << flightsFile << "\n";
             else
                cout << "Failed to save flights.\n";

             cout << "Exiting...\n";
        }

        else
        {
             cout << "Invalid choice.\n";
        }

} while (choice != 12);

return 0;
}

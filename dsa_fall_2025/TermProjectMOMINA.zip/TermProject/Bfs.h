#ifndef BFS_H
#define BFS_H

#include <iostream>
#include <queue>
#include <string>
#include <vector>
#include <climits>

using namespace std;

enum Color { white, grey, black };

class Graph
{
private:
    int V;                        // Number of airports
    int Adj[20][20];              // Adjacency matrix
    Color visited[20];
    int dist[20];
    int parent[20];
    string airportNames[20];      // Airport name list

public:

    // CONSTRUCTOR
    Graph(int size)
    {
        V = size;
        for (int i = 0; i < V; i++)
        {
            airportNames[i] = "";
            for (int j = 0; j < V; j++)
                Adj[i][j] = 0;
        }
    }

    // SET AIRPORT NAME
    void setAirportName(int index, string name)
    {
        airportNames[index] = name;
    }

    // ADD ROUTE
    void addEdge(int u, int v)
    {
        Adj[u][v] = 1;
        Adj[v][u] = 1;   // undirected route
    }

    // BFS FUNCTION
    void BFS(int source)
    {
        for (int i = 0; i < V; i++)
        {
            visited[i] = white;
            dist[i] = -1;
            parent[i] = -1;
        }

        visited[source] = grey;
        dist[source] = 0;

        queue<int> Q;
        Q.push(source);

        while (!Q.empty())
        {
            int u = Q.front();
            Q.pop();

            for (int x = 0; x < V; x++)
            {
                if (Adj[u][x] == 1 && visited[x] == white)
                {
                    visited[x] = grey;
                    dist[x] = dist[u] + 1;
                    parent[x] = u;
                    Q.push(x);
                }
            }
            visited[u] = black;
        }
        printTable();
    }

    // DISPLAY BFS TABLE
    void printTable()
    {
        cout << left
            << setw(15) << "\nAirport" << setw(15) << "Distance" << setw(15) << "Parent" << endl;

        cout << "--------------------------------------------------------" << endl;

        for (int i = 0; i < V; i++)
        {
            string parentName = (parent[i] == -1 ? "None" : airportNames[parent[i]]);

            cout << left << setw(15) << airportNames[i]<< setw(15) << dist[i]<< setw(15) << parentName<< endl;
        }
    }

    // PRINT MIN STOPS
    void printMinStops(int dest)
    {
        cout << endl;
        cout << "Minimum stops = " << dist[dest] << endl;
    }

    // PRINT ROUTE
    void printRoute(int src, int dest)
    {
        if (dist[dest] == -1)
        {
            cout << "No route found." << endl;
            return;
        }

        int path[20];
        int count = 0;
        int temp = dest;

        while (temp != -1)
        {
            path[count++] = temp;
            temp = parent[temp];
        }

        cout << "\nRoute: ";
        for (int i = count - 1; i >= 0; i--)
        {
            cout << airportNames[path[i]];
            if (i != 0) cout << " -> ";
        }
        cout << endl;
    }

// Find all simple paths from src to dest
    void findAllPathsUtil(int u, int dest, bool visited[], vector<int>& path, vector<vector<int>>& allPaths) 
    {
        visited[u] = true;
        path.push_back(u);
        if (u == dest) 
        {
            allPaths.push_back(path);
        }
        else 
        {
            for (int v = 0; v < V; ++v) 
            {
                if (Adj[u][v] == 1 && !visited[v]) 
                {
                    findAllPathsUtil(v, dest, visited, path, allPaths);
                }
            }
        }
        path.pop_back();
        visited[u] = false;
    }

    vector<vector<int>> findAllPaths(int src, int dest) 
    {
        vector<vector<int>> allPaths;
        if (src < 0 || src >= V || dest < 0 || dest >= V)
            return allPaths;
        bool visitedLocal[20] = 
        { 
            false 
        };
        vector<int> path;
        findAllPathsUtil(src, dest, visitedLocal, path, allPaths);
        return allPaths;
    }

    void printAllPathsAndOptimal(int src, int dest) 
    {
        auto all = findAllPaths(src, dest);
        if (all.empty()) 
        {
            cout << "No path exists from " << airportNames[src] << " to " << airportNames[dest] << ".\n";
            return;
        }

        cout << "\nAll possible routes from " << airportNames[src] << " to " << airportNames[dest] << ":\n";
        int minStops = INT_MAX;
        for (size_t i = 0; i < all.size(); ++i) 
        {
            int stops = (int)all[i].size() - 1;
            cout << i + 1 << ". ";
            for (int j = 0; j < (int)all[i].size(); ++j) 
            {
                cout << airportNames[all[i][j]];
                if (j + 1 < (int)all[i].size()) cout << " -> ";
            }
            cout << "   (stops: " << stops << ")" << endl;
            if (stops < minStops) minStops = stops;
        }

        cout << "\nOptimal route(s) with minimum stops (" << minStops << "):" << endl;
        for (size_t i = 0; i < all.size(); ++i) 
        {
            int stops = (int)all[i].size() - 1;
            if (stops == minStops) 
            {
                cout << "- ";
                for (int j = 0; j < (int)all[i].size(); ++j) 
                {
                    cout << airportNames[all[i][j]];
                    if (j + 1 < (int)all[i].size()) cout << " -> ";
                }
                cout << endl;
            }
        }
    }

};

#endif
//end of Bfs.h
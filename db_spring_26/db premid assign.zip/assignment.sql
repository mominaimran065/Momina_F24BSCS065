-- NEW DATABASE
CREATE DATABASE RetailDB;
USE RetailDB;

-- TABLE CREATION (CUSTOMERS)
CREATE TABLE Customers 
(
    customer_id INT PRIMARY KEY UNIQUE NOT NULL,
    customer_name VARCHAR(50) NOT NULL,
    email varchar(100) UNIQUE NOT NULL,
    city VARCHAR(50),
    gender CHAR(1) CHECK (gender IN ('M','F')),
    registration_date DATE NOT NULL DEFAULT (CURRENT_DATE)
);

-- TABLE CREATION (PRODUCTS)
CREATE TABLE Products 
(
    product_id INT PRIMARY KEY UNIQUE NOT NULL,
    product_name VARCHAR(50) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL CHECK (price >= 0),
    stock_quantity INT NOT NULL DEFAULT 0 CHECK (stock_quantity >= 0),
    is_active BOOLEAN DEFAULT TRUE
);

-- TABLE CREATION (SALES)
CREATE TABLE Sales 
(
    sale_id INT PRIMARY KEY UNIQUE NOT NULL,
    customer_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL CHECK (quantity > 0),
    sale_date DATE DEFAULT (CURRENT_DATE),
    FOREIGN KEY (customer_id) REFERENCES Customers(customer_id),
    FOREIGN KEY (product_id) REFERENCES Products(product_id)
);

-- TABLE CREATION (SUPPLIERS)
CREATE TABLE Suppliers
(
supplier_id INT PRIMARY KEY UNIQUE NOT NULL,
supplier_name VARCHAR(50) NOT NULL,
contact_email VARCHAR (100) UNIQUE,
city VARCHAR(50),
phone_number VARCHAR(20),
registration_date DATE NOT NULL DEFAULT (current_date)
);



-- INSERTION INTO (CUSTOMERS)
INSERT INTO Customers 
VALUES (1,'Ali Khan','ali.khan@gmail.com','Lahore','M','2024-01-10'),
(2,'Sara Ahmed','sara.ahmed@gmail.com','Karachi','F','2024-02-15'),
(3,'Usman Tariq','usman.tariq@gmail.com','Islamabad','M','2024-03-05'),
(4,'Hina Malik','hina.malik@gmail.com','Lahore','F','2024-04-12'),
(5,'Bilal Shah','bilal.shah@gmail.com','Faisalabad','M','2024-05-20'),
(6,'Ayesha Iqbal','ayesha.iqbal@gmail.com','Karachi','F','2024-06-01'),
(7,'Omar Raza','omar.raza@gmail.com','Lahore','M','2024-06-10'),
(8,'Zoya Khan','zoya.khan@gmail.com','Islamabad','F','2024-06-15'),
(9,'Ahmed Ali','ahmed.ali@gmail.com','Karachi','M','2024-06-20'),
(10,'Fatima Noor','fatima.noor@gmail.com','Lahore','F','2024-07-01'),
(11,'Hamza Shah','hamza.shah@gmail.com','Faisalabad','M','2024-07-05'),
(12,'Sana Iqbal','sana.iqbal@gmail.com','Islamabad','F','2024-07-10'),
(13,'Bilal Khan','bilal.khan@gmail.com','Karachi','M','2024-07-15'),
(14,'Maryam Asif','maryam.asif@gmail.com','Lahore','F','2024-07-20'),
(15,'Tariq Javed','tariq.javed@gmail.com','Faisalabad','M','2024-07-25')
;

-- INSERTION INTO (PRODUCTS)
INSERT INTO PRODUCTS
VALUES (101,'Laptop','Electronics',120000,15,1),
(102,'T-Shirt','Clothing',2500,50,0),
(103,'Rice Bag','Grocery',3500,30,1),
(104,'Headphones','Electronics',5000,20,0),
(105,'Jacket','Clothing',6000,10,1),
(106,'Desk Chair','Furniture',12000,8,1),
(107,'Notebook','Stationery',200,100,1),
(108,'Smartphone','Electronics',95000,12,0),
(109,'Coffee Maker','Appliances',8000,7,1),
(110,'Sneakers','Clothing',5500,25,1),
(111,'Microwave','Appliances',15000,5,0),
(112,'Pen Set','Stationery',300,80,0),
(113,'Rice Cooker','Appliances',5000,10,1),
(114,'Jacket','Clothing',6500,15,1),
(115,'Water Bottle','Accessories',1500,40,0)
;

-- INSERTION INTO (SALES)
INSERT INTO SALES
VALUES
(1,1,101,1,'2024-05-10'),  -- Ali buys Laptop
(2,2,102,2,'2024-05-12'),  -- Sara buys T-Shirt
(3,3,103,3,'2024-05-15'),  -- Usman buys Rice Bag
(4,4,104,1,'2024-05-18'),  -- Hina buys Headphones
(5,5,105,2,'2024-05-20'),  -- Bilal buys Jacket
(6,1,102,1,'2024-05-22'),  -- Ali buys T-Shirt again
(7,2,101,1,'2024-05-25'),  -- Sara buys Laptop
(8,3,104,2,'2024-05-28'),  -- Usman buys Headphones
(9,4,103,1,'2024-06-01'),  -- Hina buys Rice Bag
(10,5,101,1,'2024-06-03'), -- Bilal buys Laptop
(11,6,106,1,'2024-06-05'), -- Ayesha buys Desk Chair
(12,7,107,5,'2024-06-08'), -- Omar buys Notebook
(13,8,108,1,'2024-06-10'), -- Zoya buys Smartphone
(14,9,101,2,'2024-06-12'), -- Ahmed buys Laptop
(15,10,110,3,'2024-06-15')-- Fatima buys Sneakers
;

INSERT INTO SUPPLIERS
VALUES(1,'Tech Supplies','contact@techsupplies.com','Lahore','042-1236567','2024-01-10'),
(2,'Global Traders','info@globaltraders.com','Karachi','021-76543421','2024-02-15'),
(3,'Prime Distributors',NULL,'Islamabad',NULL,'2024-03-05'),
(4,'Fashion Hub','sales@fashionhub.com','Lahore','042-9876543','2024-04-12'),
(5,'Grocery World','hello@groceryworld.com','Faisalabad','041-1122334','2024-05-20'),
(6,'Office Essentials','office@essentials.com','Karachi','021-3344556','2024-05-25'),
(7,'ElectroMart','sales@electromart.com','Lahore','042-5566778','2024-06-01'),
(8,'Home Comforts','info@homecomforts.com','Islamabad','051-1122334','2024-06-05'),
(9,'Fashion Point','contact@fashionpoint.com','Karachi','021-9988776','2024-06-10'),
(10,'Fresh Foods','sales@freshfoods.com','Faisalabad','041-2233445','2024-06-15'),
(11,'Stationery Hub','info@stationeryhub.com','Lahore','042-6677889','2024-06-20'),
(12,'Gadget World','contact@gadgetworld.com','Islamabad','051-3344556','2024-06-25'),
(13,'Kitchen Supplies','sales@kitchen.com','Karachi','021-4455667','2024-06-30'),
(14,'Fashion Square','contact@fashionsquare.com','Lahore','042-7788990','2024-07-05'),
(15,'Grocery Mart','info@grocerymart.com','Faisalabad','041-5566778','2024-07-10')
;

-- QUERIES
-- List all distinct cities from which customers have registered, along with their gender,
-- ordered by city and gender.
SELECT DISTINCT city, gender
FROM customers
ORDER BY city, gender;

-- Display all active products with their original price and price after applying a 10%
-- discount, only for products with price greater than 1000. Sort results by discounted price
-- descending.
SELECT product_name, price AS original_price, 
price * 0.90 AS discounted_price
FROM products
WHERE is_active= TRUE AND price > 1000
ORDER BY discounted_price DESC;

-- show all sales where the quantity sold is greater than 1 and the sale occurred on a
-- weekday (Monday–Wednesday). Sort by sale date descending and quantity ascending.
Select *
FROM sales
WHERE quantity > 1
AND WEEKDAY(sale_date) IN (0,1,2)
ORDER BY sale_date DESC, 
quantity asc; 

-- Display the total number of products and total stock in each category. Include only
-- categories with more than 2 products and sort by total products descending.
SELECT category,
COUNT(product_id) AS total_products,
SUM(stock_quantity) as total_stock
FROM Products
GROUP BY category
HAVING COUNT(product_id) > 2
ORDER by total_products DESC;

-- Display the average and maximum price per product category, but only for categories
-- where the average price exceeds 1000. Sort the results by average price descending.
SELECT category,
AVG(price) AS avg_price,
MAX(price)  AS max_price
FROM products
GROUP BY category
HAVING AVG(price) > 1000
ORDER BY avg_price DESC;

-- Display the total quantity purchased and number of orders for each customer where
-- quantity is greater than 0. Sort by total quantity descending.
SELECT customer_id,
SUM(quantity) AS total_quantity,
COUNT(sale_id) AS no_of_Orders
FROM sales
WHERE quantity > 0
GROUP BY customer_id
ORDER BY total_quantity DESC;

-- Display the minimum, maximum, and average price per product category. Include only
-- categories where the minimum price is less than 5000 and sort by average price
-- descending.
SELECT category,
MIN(price) AS min_price,
MAX(price) AS max_price,
AVG(price) AS avg_price 
FROM products 
GROUP BY category
HAVING MIN(price) < 5000
ORDER BY avg_price DESC;

-- Display product IDs with total sales quantity greater than 2, along with the number of
-- distinct customers who bought each product. Sort by total quantity descending.
SELECT product_id,
SUM(quantity) AS total_quantity,
COUNT(DISTINCT customer_id) AS distinct_customers
FROM sales
GROUP BY product_id
HAVING SUM(quantity) > 2 
ORDER BY total_quantity DESC;

-- Display total units sold and average quantity per product. Include only products with total
-- quantity greater than 1. Sort by total units descending and average quantity ascending.
SELECT product_id,
SUM(quantity) AS totalUNITS_sold,
AVG(quantity) AS avg_quantity
FROM sales
GROUP BY product_id
HAVING SUM(quantity) > 1
ORDER BY totalUNITS_sold DESC, 
avg_quantity ASC;

-- Display all sales where quantity is greater than 1, sale date is between 
-- ‘2025-01-01’ and ‘2025-03-01’ and sale ID is even. 
-- Sort by sale date descending and quantity ascending.
SELECT *
from sales
WHERE quantity > 1 
AND sale_date BETWEEN '2024-04-01' AND '2024-06-01'
AND sale_id % 2 = 0 -- for even
ORDER BY sale_date DESC, 
quantity ASC;

-- Display categories where total stock quantity exceeds 20, along with the total number of
-- products in each category. Sort results by total stock descending.
SELECT category,
SUM(stock_quantity) AS  total_stock,
COUNT(product_id) as totAl_products
FROM products
GROUP BY category
HAVING SUM(stock_quantity) > 20
ORDER BY total_stock DESC;

-- Display customer names formatted with the first letter uppercase and the rest lowercase,
-- along with registration month and year (e.g., Feb-2025). Only include customers
-- registered before today and sort by registration date descending.
SELECT CONCAT(UPPER(LEFT(customer_name, 1)), 
LOWER (SUBSTRING(customer_name,2))) AS formatted_customer_name,
DATE_FORMAT(registration_date, '%b-%Y') as reg_month_year
FROM customers
WHERE registration_date < current_date()
ORDER BY registration_date DESC;















 

 






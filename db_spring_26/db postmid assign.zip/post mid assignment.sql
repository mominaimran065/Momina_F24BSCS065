USE db02;
SELECT 
c.customer_name,
c.segment,
c.city,
a.account_id,
a.account_type,
a.opening_balance,

COUNT(t.transaction_id) AS total_transactions,
SUM( CASE WHEN t.transaction_type = 'Deposit' THEN t.amount 
ELSE 0 END)
as total_deposits, -- calculating total deposits -- cte used
SUM( CASE WHEN t.transaction_type = 'Withdrawal' THEN t.amount 
ELSE 0 END)
as total_withdrawals, -- calculating total withdrawals -- cte used
 
 -- to chwck unusual activitIES
 CASE 
 -- high amount but no transactions
 WHEN (count(t.transaction_id) = 0 AND a.opening_balance > 10000)
 THEN 'holds Amount but is inactive'

   -- customer did only withdrawals
 WHEN SUM(CASE WHEN t.transaction_type = 'Deposit' 
           THEN 1 ELSE 0 END) = 0 
 THEN 'Only withdrawals'
 
 -- customer did only deposits
 WHEN SUM( CASE WHEN t.transaction_type = 'Withdrawal'
          THEN 1 ELSE 0 END) =0 
 THEN 'Only Deposits'
 
  -- account is inactive but has transactions
 when ( count(t.transaction_id) = 1
      AND a.opening_balance < 10000000) 
 THEN 'Inactive Account'
 
 -- if no unusual activity then everthing is normal
 ELSE 'Normal'
 END AS account_flag
 
FROM Customers c
iNNER JOIN Accounts a
ON c.customer_id =a.customer_id
left JOIN transactions t
ON a.account_id = t.account_id
GROUP BY c.customer_name,
c.segment,
c.city,
a.account_id,
a.account_type,
a.opening_balance;






--  q2  
SELECT 
c.customer_id,
c.customer_name,
c.segment,
c.city,

COUNT(t.transaction_id) AS total_transactions,
SUM( CASE WHEN t.transaction_type = 'Deposit' THEN t.amount 
ELSE 0 END)
as total_deposits, -- calculating total deposits -- cte used
SUM( CASE WHEN t.transaction_type = 'Withdrawal' THEN t.amount 
ELSE 0 END)
as total_withdrawals, -- calculating total withdrawals -- cte used

concat( CASE
-- no activity of customer
WHEN COUNT(t.transaction_id) = 0
then 'Inactive customer'

-- highly active customer
WHEN COUNT(t.transaction_id) 
> (SELECT AVG(transaction_count)
   FROM (
   SELECT COUNT(t1.transaction_id) AS transaction_count
   FROM Accounts a1
   LEFT JOIN Transactions t1
   ON a1.account_id = t1.account_id
   GROUP BY a1.customer_id)
   AS avg_table
   )
   THEN 'highly active customer'
   ELSE 'moderate active'
   END,
    CASE WHEN Count(t.transaction_id) = 0
    then ''
    ELSE CONCAT (' & ',
CASE

-- Cusotmer did more deposits
WHEN SUM(CASE WHEN t.transaction_type = 'Deposit' THEN t.amount ELSE 0 END) >
     SUM(CASE WHEN t.transaction_type = 'Withdrawal' THEN t.amount ELSE 0 END) * 2
     THEN 'deposit-oriented behavior'
    
-- Cusotmer did more withdrawals
WHEN SUM(CASE WHEN t.transaction_type = 'Withdrawal' THEN t.amount ELSE 0 END) >
     SUM(CASE WHEN t.transaction_type = 'Deposit' THEN t.amount ELSE 0 END) * 2
     THEN 'Withdrawal-oriented behavior'
   
ELSE 'balanced'
END ) -- end of concatination
END )
AS customer_behavior

FROM Customers c
iNNER JOIN Accounts a
ON c.customer_id =a.customer_id
left JOIN transactions t
ON a.account_id = t.account_id

GROUP BY c.customer_id,
c.customer_name,
c.segment,
c.city;






// AYESHA NOOR
// MOMINA IMRAN


#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

const int MAX_SUBJECTS = 5;
const int MAX_STUDENTS = 100;

class Person {
protected:
    string name;
    string cnic;
public:
    Person() {}
    Person(string n, string c) : name(n), cnic(c) {}
    virtual void displayInfo() const = 0;
    string getCNIC() const { return cnic; }
    virtual ~Person() {}
};

class Student : public Person {
    int id;
    string degreeEnrolled;
    vector<string> subjects;
    vector<int> marks;
public:
    Student(string n = "", string c = "", int i = 0, string d = "")
        : Person(n, c), id(i), degreeEnrolled(d) {}

    void setSubjectsAndMarks(const vector<string>& subjs, const vector<int>& mks) {
        subjects = subjs;
        marks = mks;
    }

    float calculateAverage() const {
        if (marks.empty()) return 0;
        int total = 0;
        for (int m : marks) total += m;
        return total / float(marks.size());
    }

    void updateDetails(string newName, string newCNIC, string newDegree) {
        name = newName;
        cnic = newCNIC;
        degreeEnrolled = newDegree;
    }

    void displayInfo() const override {
        cout << "ID: " << id << ", Name: " << name << ", CNIC: " << cnic
            << ", Degree: " << degreeEnrolled << ", Avg Marks: " << calculateAverage() << endl;
        for (size_t i = 0; i < subjects.size(); i++) {
            cout << "   " << subjects[i] << ": " << marks[i] << endl;
        }
    }

    int getID() const { return id; }
    string getName() const { return name; }
    string getDegree() const { return degreeEnrolled; }

    friend ostream& operator<<(ostream& out, const Student& s) {
        out << s.id << "," << s.name << "," << s.cnic << "," << s.degreeEnrolled;
        for (size_t i = 0; i < s.subjects.size(); ++i) {
            out << "," << s.subjects[i] << ":" << s.marks[i];
        }
        return out;
    }

    friend istream& operator>>(istream& in, Student& s) {
        string line;
        getline(in, line);
        if (line.empty()) return in;

        size_t pos = 0;
        vector<string> parts;
        while ((pos = line.find(',')) != string::npos) {
            parts.push_back(line.substr(0, pos));
            line.erase(0, pos + 1);
        }
        parts.push_back(line);

        s.id = stoi(parts[0]);
        s.name = parts[1];
        s.cnic = parts[2];
        s.degreeEnrolled = parts[3];

        s.subjects.clear();
        s.marks.clear();
        for (size_t i = 4; i < parts.size(); ++i) {
            size_t colon = parts[i].find(':');
            s.subjects.push_back(parts[i].substr(0, colon));
            s.marks.push_back(stoi(parts[i].substr(colon + 1)));
        }

        return in;
    }
};

class College {
    vector<Student> students;
public:
    void registerStudent(const Student& s) {
        if (students.size() < MAX_STUDENTS)
            students.push_back(s);
    }

    void viewAllStudents() {
        for (const Student& s : students)
            s.displayInfo();
    }

    void searchStudentByCNIC(const string& cnic) {
        for (Student& s : students) {
            if (s.getCNIC() == cnic) {
                s.displayInfo();
                return;
            }
        }
        cout << "Student not found.\n";
    }

    void updateStudentByCNIC(const string& cnic) {
        for (Student& s : students) {
            if (s.getCNIC() == cnic) {
                string newName, newCNIC, newDegree;
                cout << "Enter new name: "; getline(cin, newName);
                cout << "Enter new CNIC: "; getline(cin, newCNIC);
                cout << "Enter new degree: "; getline(cin, newDegree);
                s.updateDetails(newName, newCNIC, newDegree);
                cout << "Student updated.\n";
                return;
            }
        }
        cout << "Student not found.\n";
    }

    void saveToFile() {
        ofstream fout("students.txt");
        for (const Student& s : students)
            fout << s << endl;
        fout.close();
        cout << "Data saved to file.\n";
    }

    void loadFromFile() {
        ifstream fin("students.txt");
        if (!fin) {
            cout << "No file found.\n";
            return;
        }
        students.clear();
        Student s;
        while (fin >> s)
            students.push_back(s);
        fin.close();
        cout << "Data loaded from file.\n";
    }

    void generateMeritList() {
        if (students.empty()) {
            cout << "No students registered.\n";
            return;
        }
        sort(students.begin(), students.end(), [](const Student& a, const Student& b) {
            return a.calculateAverage() > b.calculateAverage();
            });

        cout << "\n--- Merit List ---\n";
        for (const Student& s : students)
            s.displayInfo();
    }
};

int main() {
    College myCollege;
    int choice;
    do {
        cout << "\n--- MENU ---\n";
        cout << "1. Register Student\n2. View All\n3. Search by CNIC\n4. Update Student\n";
        cout << "5. Save to File\n6. Load from File\n7. Generate Merit List\n0. Exit\nChoice: ";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            string name, cnic, degree;
            int id, nSubjects;
            vector<string> subjects;
            vector<int> marks;

            cout << "Enter ID: "; cin >> id; cin.ignore();
            cout << "Enter Name: "; getline(cin, name);
            cout << "Enter CNIC: "; getline(cin, cnic);
            cout << "Enter Degree: "; getline(cin, degree);
            cout << "How many subjects (max " << MAX_SUBJECTS << "): "; cin >> nSubjects; cin.ignore();
            for (int i = 0; i < nSubjects; ++i) {
                string subj;
                int mark;
                cout << "  Subject " << (i + 1) << " Name: "; getline(cin, subj);
                cout << "  Marks: "; cin >> mark; cin.ignore();
                subjects.push_back(subj);
                marks.push_back(mark);
            }
            Student s(name, cnic, id, degree);
            s.setSubjectsAndMarks(subjects, marks);
            myCollege.registerStudent(s);
        }
        else if (choice == 2) {
            myCollege.viewAllStudents();
        }
        else if (choice == 3) {
            string cnic;
            cout << "Enter CNIC: "; getline(cin, cnic);
            myCollege.searchStudentByCNIC(cnic);
        }
        else if (choice == 4) {
            string cnic;
            cout << "Enter CNIC to update: "; getline(cin, cnic);
            myCollege.updateStudentByCNIC(cnic);
        }
        else if (choice == 5) {
            myCollege.saveToFile();
        }
        else if (choice == 6) {
            myCollege.loadFromFile();
        }
        else if (choice == 7) {
            myCollege.generateMeritList();
        }
    } while (choice != 0);

    return 0;
}
